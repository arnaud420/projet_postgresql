CREATE TABLE IF NOT EXISTS `halls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `halls` (`id`,`name`,`created_at`,`updated_at`) VALUES (7,'Nina kraviz','2018-01-21 16:24:23.000','2018-01-21 16:24:23.000');
INSERT INTO `halls` (`id`,`name`,`created_at`,`updated_at`) VALUES (8,'Ben Klock','2018-01-21 16:25:00.000','2018-01-21 16:25:00.000');
INSERT INTO `halls` (`id`,`name`,`created_at`,`updated_at`) VALUES (9,'Paul Kalkbrenner','2018-01-21 16:25:28.000','2018-01-21 16:25:28.000');
INSERT INTO `halls` (`id`,`name`,`created_at`,`updated_at`) VALUES (11,'Nathan Joy','2018-01-21 17:16:00.000','2018-01-21 17:16:00.000');
INSERT INTO `halls` (`id`,`name`,`created_at`,`updated_at`) VALUES (12,'Zendid','2018-01-21 17:16:10.000','2018-01-21 17:16:10.000');
INSERT INTO `halls` (`id`,`name`,`created_at`,`updated_at`) VALUES (13,'Enrico Sangiuliano','2018-01-21 17:16:17.000','2018-01-21 17:16:17.000');
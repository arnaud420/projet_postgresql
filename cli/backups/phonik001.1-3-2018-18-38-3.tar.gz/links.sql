CREATE TABLE IF NOT EXISTS `links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture_id` int(10) unsigned DEFAULT NULL,
  `artist_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `links_picture_id_foreign` (`picture_id`),
  KEY `links_artist_id_foreign` (`artist_id`),
  CONSTRAINT `links_artist_id_foreign` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`id`),
  CONSTRAINT `links_picture_id_foreign` FOREIGN KEY (`picture_id`) REFERENCES `pictures` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (1,'https://google.com','Beatport',NULL,1,'2017-10-03 09:43:36.000','2017-10-03 09:43:36.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (2,'https://google.com','Facebook',NULL,1,'2017-10-03 09:46:25.000','2017-10-03 09:46:25.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (3,'https://google.com','Soundcloud',NULL,1,'2017-10-03 09:48:00.000','2017-10-03 09:48:00.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (4,'https://google.com','Facebook',NULL,2,'2017-10-03 17:51:14.000','2017-10-03 17:51:14.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (5,'https://google.com','Beatport',NULL,2,'2017-10-03 17:51:19.000','2017-10-03 17:51:19.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (6,'https://google.com','Soundcloud',NULL,2,'2017-10-03 17:51:24.000','2017-10-03 17:51:24.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (7,'https://google.com','Facebook',NULL,3,'2017-10-04 08:58:45.000','2017-10-04 08:58:45.000');
INSERT INTO `links` (`id`,`url`,`title`,`picture_id`,`artist_id`,`created_at`,`updated_at`) VALUES (8,'https://google.com','Instagran',NULL,4,'2017-10-04 13:57:33.000','2017-10-04 13:57:33.000');
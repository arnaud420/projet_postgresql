CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture_id` int(10) unsigned NOT NULL,
  `facebook_link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_picture_id_foreign` (`picture_id`),
  CONSTRAINT `events_picture_id_foreign` FOREIGN KEY (`picture_id`) REFERENCES `pictures` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `events` (`id`,`name`,`picture_id`,`facebook_link`,`created_at`,`updated_at`) VALUES (3,'Tata',16,'Toto','2017-10-03 17:45:45.000','2017-10-03 21:20:21.000');
INSERT INTO `events` (`id`,`name`,`picture_id`,`facebook_link`,`created_at`,`updated_at`) VALUES (4,'Tata',15,'Toto','2017-10-03 17:45:47.000','2017-10-03 17:45:47.000');
INSERT INTO `events` (`id`,`name`,`picture_id`,`facebook_link`,`created_at`,`updated_at`) VALUES (5,'Tata',17,'Toto','2017-10-03 17:49:15.000','2017-10-03 17:49:15.000');
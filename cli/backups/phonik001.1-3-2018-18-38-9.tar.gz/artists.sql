CREATE TABLE IF NOT EXISTS `artists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `artists_picture_id_foreign` (`picture_id`),
  CONSTRAINT `artists_picture_id_foreign` FOREIGN KEY (`picture_id`) REFERENCES `pictures` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `artists` (`id`,`name`,`description`,`email`,`picture_id`,`created_at`,`updated_at`) VALUES (1,'Ader','Nunc vero inanes flatus quorundam vile esse quicquid extra urbis pomerium nascitur aestimant praeter orbos et caelibes, nec credi potest qua obsequiorum diversitate coluntur homines sine liberis Romae.','mauhz@phonik.org',21,'2017-10-03 09:43:05.000','2017-10-04 13:55:12.000');
INSERT INTO `artists` (`id`,`name`,`description`,`email`,`picture_id`,`created_at`,`updated_at`) VALUES (2,'Nazustabal','Restabat ut Caesar post haec properaret accitus et abstergendae causa suspicionis sororem suam, eius uxorem, Constantius ad se tandem desideratam venire multis fictisque blanditiis hortabatur. quae licet ambigeret metuens saepe cruentum,','pier@phonik.org',19,'2017-10-03 09:43:23.000','2017-10-04 14:01:25.000');
INSERT INTO `artists` (`id`,`name`,`description`,`email`,`picture_id`,`created_at`,`updated_at`) VALUES (3,'Mr. CrLs','Ut enim benefici liberalesque sumus, non ut exigamus gratiam (neque enim beneficium faeneramur sed natura propensi ad liberalitatem sumus), sic amicitiam non spe mercedis adducti sed quod omnis eius fructus in ipso amore inest, expetendam putamus.','toto@example.com',18,'2017-10-04 08:53:28.000','2017-10-04 13:55:33.000');
INSERT INTO `artists` (`id`,`name`,`description`,`email`,`picture_id`,`created_at`,`updated_at`) VALUES (4,'Thomas','Hanc regionem praestitutis celebritati diebus invadere parans dux ante edictus per solitudines Aboraeque amnis herbidas ripas, suorum indicio proditus, qui admissi flagitii metu exagitati ad praesidia descivere Romana. absque ullo egressus effectu deinde tabescebat immobilis.','thomas@phonik.org',20,'2017-10-04 13:57:18.000','2017-10-04 13:58:10.000');
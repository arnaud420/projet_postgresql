CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (14,'2014_10_12_000000_create_users_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (15,'2014_10_12_100000_create_password_resets_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (16,'2017_08_06_152805_create_pictures_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (17,'2017_08_06_152855_create_infos_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (18,'2017_08_10_151915_create_artists_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (19,'2017_08_10_152004_create_links_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (20,'2017_08_29_132120_create_employees_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (21,'2017_10_01_174930_create_events_table',1);
INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES (22,'2018_01_21_154130_create_hall',2);
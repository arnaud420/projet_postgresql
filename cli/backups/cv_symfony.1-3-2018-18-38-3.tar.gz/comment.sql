CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9474526C4B89032C` (`post_id`),
  CONSTRAINT `FK_9474526C4B89032C` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `comment` (`id`,`post_id`,`name`,`email`,`content`) VALUES (1,1,'azeaz','ezaeza','ezaeaze');
INSERT INTO `comment` (`id`,`post_id`,`name`,`email`,`content`) VALUES (2,1,'azeaze','azeaze','zaeaze');
INSERT INTO `comment` (`id`,`post_id`,`name`,`email`,`content`) VALUES (3,2,'azea','zeaze','az');
CREATE TABLE IF NOT EXISTS `caio_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (1,1,'nickname','admin');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (2,1,'first_name','');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (3,1,'last_name','');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (4,1,'description','');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (5,1,'rich_editing','true');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (6,1,'syntax_highlighting','true');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (7,1,'comment_shortcuts','false');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (8,1,'admin_color','fresh');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (9,1,'use_ssl','0');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (10,1,'show_admin_bar_front','true');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (11,1,'locale','');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (12,1,'caio_capabilities','a:1:{s:13:\"administrator\";b:1;}');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (13,1,'caio_user_level','10');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (14,1,'dismissed_wp_pointers','');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (15,1,'show_welcome_panel','1');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (17,1,'caio_dashboard_quick_press_last_post_id','45');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (18,1,'community-events-location','a:1:{s:2:\"ip\";s:2:\"::\";}');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (19,1,'session_tokens','a:2:{s:64:\"b5433fdfa94ac6d350372841215982d4a7fb9e5f171ddd61e3ef8f4a4f28ab3f\";a:4:{s:10:\"expiration\";i:1522581913;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:105:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36\";s:5:\"login\";i:1522409113;}s:64:\"59ee5f2521149e17c7c92a2005d95a403654089b2aaeb3d4a7a2e70ecb991029\";a:4:{s:10:\"expiration\";i:1522678815;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:105:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36\";s:5:\"login\";i:1522506015;}}');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (20,1,'caio_user-settings','libraryContent=browse&editor=tinymce');
INSERT INTO `caio_usermeta` (`umeta_id`,`user_id`,`meta_key`,`meta_value`) VALUES (21,1,'caio_user-settings-time','1522506038');
CREATE TABLE IF NOT EXISTS `caio_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `caio_terms` (`term_id`,`name`,`slug`,`term_group`) VALUES (1,'Non classé','non-classe',0);
INSERT INTO `caio_terms` (`term_id`,`name`,`slug`,`term_group`) VALUES (2,'test','test',0);
INSERT INTO `caio_terms` (`term_id`,`name`,`slug`,`term_group`) VALUES (3,'hello','hello',0);
INSERT INTO `caio_terms` (`term_id`,`name`,`slug`,`term_group`) VALUES (4,'world','world',0);
CREATE TABLE IF NOT EXISTS `caio_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `caio_term_taxonomy` (`term_taxonomy_id`,`term_id`,`taxonomy`,`description`,`parent`,`count`) VALUES (1,1,'category','',0,1);
INSERT INTO `caio_term_taxonomy` (`term_taxonomy_id`,`term_id`,`taxonomy`,`description`,`parent`,`count`) VALUES (2,2,'post_tag','',0,0);
INSERT INTO `caio_term_taxonomy` (`term_taxonomy_id`,`term_id`,`taxonomy`,`description`,`parent`,`count`) VALUES (3,3,'post_tag','',0,0);
INSERT INTO `caio_term_taxonomy` (`term_taxonomy_id`,`term_id`,`taxonomy`,`description`,`parent`,`count`) VALUES (4,4,'post_tag','',0,0);
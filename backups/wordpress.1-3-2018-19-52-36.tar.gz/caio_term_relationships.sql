CREATE TABLE IF NOT EXISTS `caio_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (1,1,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (26,1,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (26,2,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (26,3,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (26,4,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (28,1,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (30,1,0);
INSERT INTO `caio_term_relationships` (`object_id`,`term_taxonomy_id`,`term_order`) VALUES (41,1,0);
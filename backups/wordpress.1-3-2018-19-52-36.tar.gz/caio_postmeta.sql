CREATE TABLE IF NOT EXISTS `caio_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (1,2,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (2,2,'_edit_lock','1518349201:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (3,4,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (4,4,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (5,4,'_edit_lock','1522506814:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (6,6,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (7,6,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (8,6,'_edit_lock','1518357071:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (9,8,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (10,8,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (11,8,'_edit_lock','1518349574:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (12,10,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (13,10,'_wp_page_template','actualites.php');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (14,10,'_edit_lock','1518349805:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (15,12,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (16,12,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (17,12,'_edit_lock','1518349603:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (18,14,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (19,14,'_edit_lock','1518350111:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (20,14,'_wp_page_template','extranet.php');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (21,16,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (22,16,'_edit_lock','1518349634:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (23,16,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (24,18,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (25,18,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (26,18,'_edit_lock','1518349646:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (27,20,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (28,20,'_edit_lock','1520794498:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (29,20,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (30,22,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (31,22,'_edit_lock','1518349759:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (32,22,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (33,1,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (34,1,'_edit_lock','1521036975:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (35,26,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (36,26,'_edit_lock','1522410108:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (39,28,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (42,28,'_edit_lock','1521037506:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (43,30,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (46,30,'_edit_lock','1521041999:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (47,33,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (48,33,'_wp_page_template','default');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (49,33,'_edit_lock','1520794670:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (52,35,'_wp_attached_file','2018/02/creacut3.png');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (53,35,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:1906;s:6:\"height\";i:959;s:4:\"file\";s:20:\"2018/02/creacut3.png\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (54,30,'_thumbnail_id','35');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (57,36,'_wp_attached_file','2018/02/IMG_4196-copy.jpg');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (58,36,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:4925;s:6:\"height\";i:3251;s:4:\"file\";s:25:\"2018/02/IMG_4196-copy.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:7:\"AnWenli\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1496766963\";s:9:\"copyright\";s:7:\"AnWenli\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (59,28,'_thumbnail_id','36');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (62,37,'_wp_attached_file','2018/02/main_cafe.jpg');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (63,37,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:5184;s:6:\"height\";i:3456;s:4:\"file\";s:21:\"2018/02/main_cafe.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:7:\"AnWenli\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1496764815\";s:9:\"copyright\";s:7:\"AnWenli\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (64,26,'_thumbnail_id','37');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (65,40,'_wp_attached_file','2018/03/baniere.jpg');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (66,40,'_wp_attachment_metadata','a:4:{s:5:\"width\";i:1900;s:6:\"height\";i:300;s:4:\"file\";s:19:\"2018/03/baniere.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (67,4,'_thumbnail_id','40');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (68,41,'_edit_last','1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (69,41,'_edit_lock','1521379203:1');
INSERT INTO `caio_postmeta` (`meta_id`,`post_id`,`meta_key`,`meta_value`) VALUES (70,42,'_wp_attached_file','2018/03/SITE-2017.pdf');
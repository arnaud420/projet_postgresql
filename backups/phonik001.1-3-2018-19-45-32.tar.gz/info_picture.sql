CREATE TABLE IF NOT EXISTS `info_picture` (
  `info_id` int(10) unsigned NOT NULL,
  `picture_id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`info_id`,`picture_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `info_picture` (`info_id`,`picture_id`,`title`,`subtitle`) VALUES (1,3,'Phonik Records','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus dignissim eros vitae aliquam ultrices. Etiam ac scelerisque ipsum. Duis et viverra ante, a dapibus mi.');
INSERT INTO `info_picture` (`info_id`,`picture_id`,`title`,`subtitle`) VALUES (1,11,'Enrico Sangiuliano - BT59','Photos & Vidéos');
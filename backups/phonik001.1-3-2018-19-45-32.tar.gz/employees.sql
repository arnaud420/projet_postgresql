CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_email_unique` (`email`),
  KEY `employees_picture_id_foreign` (`picture_id`),
  CONSTRAINT `employees_picture_id_foreign` FOREIGN KEY (`picture_id`) REFERENCES `pictures` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employees` (`id`,`name`,`role`,`email`,`picture_id`,`created_at`,`updated_at`) VALUES (1,'Pier','Président','pier@phonik.org',12,'2017-10-03 17:51:54.000','2017-10-03 17:51:54.000');
INSERT INTO `employees` (`id`,`name`,`role`,`email`,`picture_id`,`created_at`,`updated_at`) VALUES (2,'Toto','Mascotte','toto@phonik.org',11,'2017-10-03 17:52:13.000','2017-10-03 17:52:13.000');
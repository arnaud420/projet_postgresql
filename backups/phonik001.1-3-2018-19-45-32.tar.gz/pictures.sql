CREATE TABLE IF NOT EXISTS `pictures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (1,'storage/pictures/AsUQs8f0lbscQniT9UDCHOpumciGNQFsetsHv9PP.jpeg','AsUQs8f0lbscQniT9UDCHOpumciGNQFsetsHv9PP.jpeg','','2017-10-03 09:36:25.000','2017-10-03 09:36:25.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (2,'storage/pictures/4Lm34BSzfrSJXtJdrH3dJAJCyju8wVqkcFbKH6ZS.jpeg','4Lm34BSzfrSJXtJdrH3dJAJCyju8wVqkcFbKH6ZS.jpeg','','2017-10-03 09:36:29.000','2017-10-03 09:36:29.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (3,'storage/pictures/vpzjXl3qekdFCxBgud3t9k4Z763Ub3g54GItuJSI.jpeg','vpzjXl3qekdFCxBgud3t9k4Z763Ub3g54GItuJSI.jpeg','','2017-10-03 09:36:30.000','2017-10-03 09:36:30.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (5,'storage/pictures/DjTFuhuXdA1SahGj7oM7Yy9HgBJ7QtM81msSAImk.png','DjTFuhuXdA1SahGj7oM7Yy9HgBJ7QtM81msSAImk.png','','2017-10-03 09:36:30.000','2017-10-03 09:36:30.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (6,'storage/pictures/D2kkgZYmLFfitvEXvH6tRWBwkUzarIByWyVmqdWu.jpeg','D2kkgZYmLFfitvEXvH6tRWBwkUzarIByWyVmqdWu.jpeg','','2017-10-03 09:36:30.000','2017-10-03 09:36:30.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (10,'storage/pictures/DykPdrYTtCsmOfgQg3tsSaPc5DZsxColRTzGHVCt.jpeg','DykPdrYTtCsmOfgQg3tsSaPc5DZsxColRTzGHVCt.jpeg','','2017-10-03 09:37:01.000','2017-10-03 09:37:01.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (11,'storage/pictures/LlkMIcuHwvenYBSqMRI6ETLCunn8LpFItxDZRz3U.jpeg','LlkMIcuHwvenYBSqMRI6ETLCunn8LpFItxDZRz3U.jpeg','','2017-10-03 09:37:01.000','2017-10-03 09:37:01.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (12,'storage/pictures/FXb9cy7vyGVRE3zOs3d8v7MBY4QjSLRDGqVgHC1y.jpeg','FXb9cy7vyGVRE3zOs3d8v7MBY4QjSLRDGqVgHC1y.jpeg','','2017-10-03 09:37:02.000','2017-10-03 09:37:02.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (13,'storage/pictures/3BWDL7atR4q5O1MPo0J8jJqcNucF02mMAmAiD0lv.jpeg','3BWDL7atR4q5O1MPo0J8jJqcNucF02mMAmAiD0lv.jpeg','','2017-10-03 09:37:02.000','2017-10-03 09:37:02.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (14,'storage/pictures/UUJiVztzz3ijgsCy21FMubEtSdXmNYx938KQnbac.jpeg','UUJiVztzz3ijgsCy21FMubEtSdXmNYx938KQnbac.jpeg','','2017-10-03 17:31:16.000','2017-10-03 17:31:16.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (15,'storage/pictures/JspC0SFGyHJf8T20c1jzZo72QtAEfsjlBGpIx05j.jpeg','JspC0SFGyHJf8T20c1jzZo72QtAEfsjlBGpIx05j.jpeg','','2017-10-03 17:31:16.000','2017-10-03 17:31:16.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (16,'storage/pictures/ZODvPKzuG7pjDKeEfAMNs9ksdUjkEIejIpAZUQkI.jpeg','ZODvPKzuG7pjDKeEfAMNs9ksdUjkEIejIpAZUQkI.jpeg','','2017-10-03 17:31:16.000','2017-10-03 17:31:16.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (17,'storage/pictures/EjAcl6m7oX2O1fki9VO2S9bpMlMXLh8JLFYWQVsx.jpeg','EjAcl6m7oX2O1fki9VO2S9bpMlMXLh8JLFYWQVsx.jpeg','','2017-10-03 17:31:16.000','2017-10-03 17:31:16.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (18,'storage/pictures/QVYg8KdoaF3RRWE09O21RmBEnf5ZcYdmUpoqfuEQ.jpeg','QVYg8KdoaF3RRWE09O21RmBEnf5ZcYdmUpoqfuEQ.jpeg','','2017-10-04 13:11:22.000','2017-10-04 13:11:22.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (19,'storage/pictures/MYYYWUyV2mJTj0Oeu4NODTQx3l26zX3eGtZ9rys6.jpeg','MYYYWUyV2mJTj0Oeu4NODTQx3l26zX3eGtZ9rys6.jpeg','','2017-10-04 13:11:52.000','2017-10-04 13:11:52.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (20,'storage/pictures/NRqZ5SLdsfYCXQ4rZNVG34WV63gowo115D0Tm2D5.jpeg','NRqZ5SLdsfYCXQ4rZNVG34WV63gowo115D0Tm2D5.jpeg','','2017-10-04 13:12:02.000','2017-10-04 13:12:02.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (21,'storage/pictures/alWFxSc4pGgYdIejRIKaOuk88NpK51Yst5NIfP9N.jpeg','alWFxSc4pGgYdIejRIKaOuk88NpK51Yst5NIfP9N.jpeg','','2017-10-04 13:12:19.000','2017-10-04 13:12:19.000');
INSERT INTO `pictures` (`id`,`path`,`filename`,`description`,`created_at`,`updated_at`) VALUES (22,'storage/pictures/RmSFiDBBW3HSlKaUEHAy6IrhFx8mwhGpWM8qnRiV.jpeg','RmSFiDBBW3HSlKaUEHAy6IrhFx8mwhGpWM8qnRiV.jpeg','','2018-01-17 16:10:36.000','2018-01-17 16:10:36.000');